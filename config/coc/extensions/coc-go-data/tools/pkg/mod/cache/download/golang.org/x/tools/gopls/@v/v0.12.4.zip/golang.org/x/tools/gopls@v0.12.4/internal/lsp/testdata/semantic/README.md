The golden files are the output of `gopls semtok <src-file>`, with `-- semantic --`
inserted as the first line (the spaces are mandatory) and an extra newline at the end.
