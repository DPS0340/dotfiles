// Package pkg is a nice package.
//
// Deprecated: Alas, it is deprecated.
package pkg
