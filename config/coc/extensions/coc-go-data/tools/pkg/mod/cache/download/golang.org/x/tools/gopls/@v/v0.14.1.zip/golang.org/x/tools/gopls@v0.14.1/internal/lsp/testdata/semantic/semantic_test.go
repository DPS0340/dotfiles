package semantictokens

import (
	"os"
	"testing"
)

func TestSemanticTokens(t *testing.T) {
	a, _ := os.Getwd()
	// climb up to find internal/lsp
	// find all the .go files

}
