---
name: 💢 False positive in Staticcheck
about: Your code is fine but Staticcheck complains about it, anyway.
labels: false-positive, needs-triage
title: ""
---
<!--
Please make sure to include the following information in your issue report:

- The output of 'staticcheck -version'
- The output of 'staticcheck -debug.version' (it is fine if this command fails)
- The output of 'go version'
- The output of 'go env'
- Exactly which command you ran
- Output of the command and what's wrong with the output
- Where we can read the code you're running Staticcheck on
  (GitHub repo, link to playground, code embedded in the issue, ...)
-->

